export { default as Aroundme } from '../..\\components\\aroundme.vue'
export { default as BestStores } from '../..\\components\\BestStores.vue'
export { default as Footer } from '../..\\components\\Footer.vue'
export { default as Header } from '../..\\components\\Header.vue'
export { default as Slider } from '../..\\components\\Slider.vue'
export { default as TodayDiscounts } from '../..\\components\\TodayDiscounts.vue'

export const LazyAroundme = import('../..\\components\\aroundme.vue' /* webpackChunkName: "components_aroundme'}" */).then(c => c.default || c)
export const LazyBestStores = import('../..\\components\\BestStores.vue' /* webpackChunkName: "components_BestStores'}" */).then(c => c.default || c)
export const LazyFooter = import('../..\\components\\Footer.vue' /* webpackChunkName: "components_Footer'}" */).then(c => c.default || c)
export const LazyHeader = import('../..\\components\\Header.vue' /* webpackChunkName: "components_Header'}" */).then(c => c.default || c)
export const LazySlider = import('../..\\components\\Slider.vue' /* webpackChunkName: "components_Slider'}" */).then(c => c.default || c)
export const LazyTodayDiscounts = import('../..\\components\\TodayDiscounts.vue' /* webpackChunkName: "components_TodayDiscounts'}" */).then(c => c.default || c)
