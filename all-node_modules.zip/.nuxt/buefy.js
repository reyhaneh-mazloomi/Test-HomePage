import Vue from 'vue'
import Buefy from 'buefy'

Vue.use(Buefy, {
  "css": true,
  "materialDesignIcons": true,
  "materialDesignIconsHRef": "//cdn.materialdesignicons.com/5.0.45/css/materialdesignicons.min.css"
})